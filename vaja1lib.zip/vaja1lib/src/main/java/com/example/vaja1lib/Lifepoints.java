package com.example.vaja1lib;

public interface Lifepoints {
    double setHP();
}
