package com.example.vaja1lib;

public class Underaged extends Exception {
    @Override
    public String toString(){
        return "Zal ste premladi za sodelovanje";
    }
}
