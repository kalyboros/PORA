package com.example.libdatastructure;

public class IzjemaNegativnaTeza extends Exception {
    @Override
    public String toString() {
        return "IzjemaNegativnaTeza{}";
    }
}
