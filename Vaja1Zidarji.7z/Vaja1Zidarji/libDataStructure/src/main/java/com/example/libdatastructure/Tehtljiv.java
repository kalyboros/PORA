package com.example.libdatastructure;

public interface Tehtljiv {
    double getTeza();
}
